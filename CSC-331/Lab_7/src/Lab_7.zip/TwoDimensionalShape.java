/**
 * @author Sinclair DeYoung
 * @section CSC 331-003
 * @purpose for two dimensional shapes
 * @date 03-11-2023
 */
public abstract class TwoDimensionalShape extends Shape{
    public abstract double getArea();
}
