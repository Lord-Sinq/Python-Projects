/**
 * @author Sinclair DeYoung
 * @section CSC 331-003
 * @purpose simple method holding the path to the other methods
 * @date 03-11-2023
 */
public class Shape {
    @Override
    public String toString(){
        return String.format("%s\n".getClass().getName());
    }
}
