/**
 * @purpose Transportation
 * @author DeYoung,Pare,Painter
 * @date 19-10-2023
 * @section CSC 331-003
 */
public class Bike extends LandTransportation{
    //constructor
    public Bike(String type, int cost, boolean isTicket, double averageSpeed, int passengersAllowed,String fuelType){
        super(type, cost, isTicket, averageSpeed,passengersAllowed, fuelType);
    }


}
